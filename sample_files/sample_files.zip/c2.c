#include <stdio.h>
int main() {
   printf("Goodbye, World!");
   return 0;
}